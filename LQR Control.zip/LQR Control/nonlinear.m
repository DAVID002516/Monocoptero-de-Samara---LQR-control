function dx = nonlinear(phi,theta,up,v,w,pp,q,r,n,delta_f)
%function dx = nonlinear_dynamics(phi,theta,psi,up,v,w,pp,q,r,xp,y,z,n,delta_f)
    dx = zeros(12,2);
        %Estados
%phi = x(1); theta = x(2); psi = x(3); up = x(4); v = x(5); w = x(6);
%pp = x(7); q = x(8); r = x(9); xp = x(10); y = x(11); z = x(12);
    %Entradas
 %   n = u(1); delta_f = u(2);
    
    %Salidas
    nw_dot(1) = dx(1); nw_dot(2) = dx(2); vc_dot(1) = dx(3); vc_dot(2) = dx(4); vc_dot(3) = dx(5);
    wc_dot(1) = dx(6); wc_dot(2) = dx(7); wc_dot(3) = dx(8);

% Constantes monocoptero
CL0 = 0.4;        % -
CLa = 6.8755;    % 1/rad
CLd = 1.17;        % 1/rad
CLq = 5.8;        % 1/rad
CD0 = 0.02;        % -
CDa = 0.063;       % 1/rad
CDd = 0.01;        % 1/rad
CM0 = -0.0950;
% -
CMa = -0.1;        % 1/rad
CMd = -0.1425;     % 1/rad
CMq = -2.5;        % 1/rad
m = 0.4220;        % kg
theta_p = 0.384;   % rad
rho = 1.1;         % kg/m^3
D = 0.12;          % m
Ctm = 0.4;         % -
Ix = 0.04;         % kg*m^2
Iy = 0.03;        % kg*m^2
Iz = 0.07;        % kg*m^2
g = 9.807;         % m/s^2

    % Transformation matrix from body angular velocity to Tait-Bryan rates
    W = [ 1, 0         ;
      0, cos(phi)   ];

    Winv = inv(W);
  %
    % Rotation matrix from body to world frame, input: roll, pitch, yaw
    R = [cos(theta)*cos(psi), sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi) ;
     cos(theta)*sin(psi), sin(phi)*sin(theta)*sin(psi)+cos(phi)*cos(psi)];

    % Matrix of mass inertia
    I = [Ix             -0.001           7.868*10^(-5)  ;
         -0.001          Iy             -7.185*10^(-5)  ;
         7.868*10^(-5)  -7.185*10^(-5)      Iz];
 
 %Definciones
 
    %Ra = 2*10^(-2);                  % Radio del disco
    Adisk = 0.019;      % Area del disco
    Rl = 0.4000; % Wingspan
    e = 0.08; %excentricidad en metros
    vi = sqrt(m*g/(2*rho*pi*Rl^2));    % Velocidad inducida
    lbe = (Rl/2+e);          % radio vector del blade element % Es de otro paper el valor
    vce = [up;v;w] + cross([pp;q;r],[lbe;0;0])+[0;0;vi]; % Vector de la velocidad del blade element
    T = rho*n^2*D^4*Ctm;    % Empuje 
    qb = 0.5*rho*(norm(vce))^2;% Presion dinamica
    a_inc = 0.1919; % angulo de incidencia 11 grados
    a_atk = atan(vce(3,1)/(vce(2,1))); % angulo de ataque Up/Ut
    a_eff = a_inc - a_atk; % angulo de efectivo de ataque
    c = 0.175; % Distancia media del chord en metros 150, 200
    S = 0.0190; % m^2 Area del pala % Es de  otro paper el valor
    CL = CL0 + CLa*a_eff + CLd*delta_f + CLq*q*c/(2*norm(vce)); %Coeficiente aerodinamico de sustentacion
    CD = CD0 + CDa*abs(a_eff) + CDd*abs(delta_f); % Coeficiente aerodinamico de arrastre
    dL =  qb*CL*S;
    dD =  qb*CD*S;
    
   

% Coeficiente aerodinamico del momento en el monocoptero
CM1 = CM0 + CMa*a_eff + CMd*delta_f + CMq*0.5*q*c/(norm(vce));
    
    % Fuerza aerodinamica
    dF1 = dD*cos(a_atk) + dL*sin(a_atk); % dA debe tenderer F1 = 0
    dF3 = dL*cos(a_atk) - dD*sin(a_atk);% dN
    dM = qb*c*CM1*S; % dM
    %dSp = 0.5*rho*norm(vce)*vce(2,1)*CD*S;% Fuerza de respuesta del aleron (valor minimo no considerado)
    
    
    Fa = [-dF1; 0; -dF3];
    Fm = [0;T*cos(theta_p);T*sin(theta_p)];
    
    %Corregir los torques
    
    CA = [0.0118830; lbe+e; 0.0027860];    % posicion del centro aerodinamico
    CM = [-0.203288; -0.00775; -0.0707140]; % posicion del centro de masa del motor
    COM = [0.0108830; 0.0004150; 0.0037860];% posicion del centro de masa del UAV
    
    Sm = CM - COM; % Vector de distancia del centro de masa del motor al centro de masa del cuerpo
    Sa = CA - COM; % Vector de distancia del centro de masa del centro aerodinamico al COM
    
    %Torque aerodinamico
    ta = cross(Sa, Fa) + [0;dM;0];
    
    %Torque del motor
    tm = cross(Sm,Fm);
    
    %Torque en el cuerpo
    tc = ta+tm;%[-up/5+20*w*up;v/390;-w/86];
    
    %Fuerzas en el cuerpo
    Fc = Fa + Fm + R'*[0;0;m*g]; %

% Vectores de los estados
nw = [phi theta].';     % Orientacion (diagrama inercial)
vc = [up v w].';  % Velocidad lineal (diagrama del cuerpo)
wc = [pp q r].';  % Velocidad angular (diagrama del cuerpo)
%pw = [xp y z].';  % Posicion (diagrama inercial)


%Vector total del estado
X = [nw;vc; wc; pw]; %Se elimina las variables (yaw, x,y,z)

% Vector de entrada
U = [n; delta_f];

%% Dinamica translacional
pw_dot = R*vc;
vc_dot = 1/m*Fc-cross(wc, vc);

%% Dinamica rotacional
nw_dot = Winv*wc;
wc_dot = inv(I)*(tc-cross(wc, I*wc));

% Modelo no-lineal
dx = [nw_dot(1);
      nw_dot(2);
      vc_dot;
      wc_dot];

end    