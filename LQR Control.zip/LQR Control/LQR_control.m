%
%
%  A.A. Rodriguez
%  EEE598C:  Multivariable Control
%  Spring 1998
%
%  Copyright 1998
%
%
%********************************
%**                            **
%**  F404 Engine MATLAB Macro  **
%**                            **
%********************************
%


%***************************************************************************
%
% Topical Table of Contents
%
% Unscaled State Space
% Natural Modes - Eigenvalues and Eigenvectors
% Modal Analysis - Excitation of Individual Modes
% Transmission Zeros and Directions
% Zero-Pole-Gain form of all Transfer Functions
% Controllability Rank Test
% Observability Rank Test
% Frequency Response - Unscaled Singular Values
% SVD Analysis at DC
% SVD Analysis at another frequency
% Step Responses
% Variable Scaling
% Frequency Response - Scaled Singular Values
% LGG/LTRO (Linear Quadratic Gaussian with Loop Transfer Recovery at Plant Output) Design
%          Form Design Plant - Augment Plant with Integrators at Plant Input
%          Design Plant Singular Values
%          Design Target Loop Using Kalman Filter Theory
%                  Filter Open Loop: Matching at all Frequencies
%                  Adjust Target Loop Bandwidth
%                  Target Singular Values: Loop, Sensitivity, Complementary Sensitivity
%          Recover Target Loop Via Cheap Control Problem
%          Compensator Analysis: poles, zeros, singular values
%          Open Loop Analysis: poles, zeros, singular values
%          Closed Loop Analysis: poles, zeros, Sensitivity and Complemenatary Sensitivity singular values
%                                Postmultiplicative Error Robustness Test
%
%

clear % clear all variables
%
%***************************************************************************
%
% Unscaled State Space Dynamics
%
% u = [ W_f (pph)  A_8 (sq in) ]
% x = [ N_2 (rpm)  N_25 (rpm)  T_45 (deg Fah) ]
% y = [ N_2 (rpm)              T_45 (deg Fah) ]
% Modelo Reducido
ap=[

   -0.0000  -41.1497         0    1.0000   -0.0058    0.0652;
   40.9742         0         0         0    0.9961    0.0883;
    0.8645   -0.6380   -2.0092    0.0099    0.4119    0.3431;
         0         0   -7.6268   -0.0080   42.4066   -2.1632;
         0         0   -0.3310  -40.8076   -0.0828    3.0034;
         0         0   -1.8504    0.5099    0.6814    0.0250];


bp =[

         0         0;
         0         0;
   -0.0867   -3.8142;
   -0.1683  -14.5079;
   -0.2660   -1.5816;
    0.2769   -0.5793];

     
cp = eye(6);% w 

dp = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]');
%***************************************************************************
%
% FACTS ON SCALING: Scaling affects the shape of singular value plots.
%                   It does not alter pole locations, zero locations.
%                   It does alter directionality information.
%
%
% Scaling Matrices
%
%  unew = su uold
%  xnew = sx xold
%  ynew = sy yold
%
%
% New Control Variables
%     unew =  [ delta_e, elevator deflection from trim (deg)
%               delta_f, flaperon deflection (deg) ]
%
%
% New State Variables
%      xnew  = [ theta, perturbed pitch angle from trim (deg) 
%                gamma, perturbed flight path angle from trim (deg)
%                    q, pitch rate (deg/sec)
%                    u, perturbation from horizontal speed (ft/sec)  ]
%
%
% New Output Variables
%      ynew = [ theta, perturbed pitch angle from trim (deg)
%               gamma, perturbed flight path angle from trim (deg) ]
%
%r2d = 180/pi;
%su = diag( [r2d, r2d] )

%sx = diag([1, 1, 1, 1, 1, 1, 1, 1])


%***************************************************************************
%
% Natural Modes: Poles (Eigenvalues), Eigenvectors
%
[evec,eval] = eig(ap)   % evec contains eigenvectors
                        % eval contains poles or eigenvalues
                 
%***************************************************************************
%
% Unscaled Modal Analysis: We want to examine the natural modes (tendencies) of the F404 engine.
%
%
t = [0:0.1:25];
u = [0*t' 0*t'];         % Set input u to zero for all time in order to generate zero input response;
                         % i.e. response to an initial condition x_o.

%
% Excite F404 (slow) temperature mode.
% This mode 
%            is associated with a pole at s = - 0.4.
%            has a time constant of  2.5 sec and settles in about 12.5 sec.
%            is the slowest of the F404's three (3) modes.
%            is associated with T_45
% Comment: It takes a long time to change temperature!
%
y = lsim(ss(ap, bp, eye(6,6), 0*ones(6,2)), u, t, evec(:,1));% y = lsim(ss(ap, bp, eye(3,3), 0*ones(3,2)), u, t, evec(:,1));
figure(1)
plot(t,y)
grid
title('F404 Slow Temperature Mode: x_o = [ 0 0 1 ]')
ylabel('States')
xlabel('Time (seconds)')

%
% Excite slow rpm mode.
% This mode 
%            is associated with a pole at s =  -0.8963.
%            has a time constant of  1.12 sec and settles in about 5.58 sec.
%            is the slowest of the F404's two rpm modes.
%            is associated with N_2 and  N_25.
%
y = lsim(ss(ap, bp, eye(6,6), 0*ones(6,2)), u, t, evec(:,3)); 
figure(2)
plot(t,y)
grid
title('F404 Slow RPM Mode: x_o = [ -0.9638 -0.2245 0.1440 ]')
ylabel('States')
xlabel('Time (seconds)')

%
% Excite fast rpm mode.
% This mode 
%            is associated with a pole at s =  -2.7937.
%            has a time constant of  0.36 sec and settles in about 1.79 sec.
%            is the fastest of the F404's two rpm modes.
%            is associated with N_2 and  N_25.
%
y = lsim(ss(ap, bp, eye(6,6), 0*ones(6,2)), u, t, evec(:,2)); 
figure(3)
plot(t,y)
grid
title('F404 Fast RPM Mode: x_o = [ 0.8676  -0.4781  -0.1368 ]')
ylabel('States')
xlabel('Time (seconds)')


%return

%***************************************************************************
%
% Transmission Zeros
%
%z = tzero(ss(ap,bp,cp,dp))                % transmission zeros
[p,z] = pzmap(ss(ap,bp,cp,dp))                % transmission zeros
%zdir = null([z*eye(8)- ap  -bp; cp dp])   % transmission zero directions

%***************************************************************************
%
%
% F404 Engine TRANSFER FUNCTIONS: From u_i to x_j
%
sys = zpk(ss(ap,bp,eye(6,6),0*ones(6,2))) % Zeros, Poles, and Gains fron u_i to x_j



%***************************************************************************
%
% Controllability 
%
cm = [bp ap*bp (ap^2)*bp]  % Controllability Matrix
rcm= rank(cm)              % Rank of Controllability Matrix


%***************************************************************************
%
% Observability
%
om = [cp; 
      cp*ap;
      cp*(ap^2) ]          % Observability Matrix
rom = rank(om)             % Rank of Observability Matrix

%return

%***************************************************************************
%
%
% F404 FREQUENCY RESPONSE: Unscaled Singular Values
%
% u = [ W_f (pph)  A_8 (sq in) ]
% x = [ N_2 (rpm)  N_25 (rpm)  T_45 (deg Fah) ]
% y = [ N_2 (rpm)              T_45 (deg Fah) ]
%
w = logspace(-2,3,100);
sv = sigma(ss(ap, bp, cp, dp),w);
sv = 20*log10(sv);
figure(4)
semilogx(w, sv)
%clear sv
title('Outputs: N_2, T_45; Inputs: W_f/110, A_8/22')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%return

%***************************************************************************
%
% F404 SVD ANALYSIS at DC
%
dc =  cp*inv(-ap)*bp
[udc,sdc,vdc] = svd(dc)


%***************************************************************************
%
% F404 SVD Analysis at w = 0.1 rad/sec
%
s = j*0.1
g = cp*inv(s*eye(6)-ap)*bp + dp
[u, s, v ] = svd(g)

%***************************************************************************
%
% Step Response
%
t = [0:0.1:25];
y = step(ss(ap, bp, eye(6,6), 0*ones(6,2)), t); % Step response for each state and each input

%
% Step Response due to W_f
%

%
% N_2: Due to W_f
%
figure(5)
plot(t,y(:,1,1))
grid
title('N_2 response for W_f =  Unit Step')
ylabel('N_2 (rpm)')
xlabel('Time (seconds)')

%return

%
% N_25: Due to W_f
%
figure(6)
plot(t,y(:,2,1))
grid
title('N_{25} response for W_f =  Unit Step')
ylabel('N_{25} (rpm)')
xlabel('Time (seconds)')

%return

%
% T_45: Due to W_f
%
figure(7)
plot(t,y(:,3,1))
grid
title('T_{45} response for W_f =  Unit Step')
ylabel('T_{45} (deg F)')
xlabel('Time (seconds)')

%return

%
% Step Response due to A_8
%

%
% N_2: Due to A_8
%
figure(8)
plot(t,y(:,1,2))
grid
title('N_2 response for A_8 =  Unit Step')
ylabel('N_2 (rpm)')
xlabel('Time (seconds)')

%return

%
% N_25: Due to W_f
%

figure(9)
plot(t,y(:,2,2))
grid
title('N_{25} response for A_8 =  Unit Step')
ylabel('N_{25} (rpm)')
xlabel('Time (seconds)')

%return

%
% T_45: Due to W_f
%
figure(10)
plot(t,y(:,3,2))
grid
title('T_{45} response for A_8 =  Unit Step')
ylabel('T_{45} (deg F)')
xlabel('Time (seconds)')

%return

%return

%
% FACTS ON SCALING: Scaling affects the shape of singular value plots.
%                   It does not alter pole locations, zero locations.
%                   It does alter directionality information.
%

%
% Scaling Matrices
%
%  unew = su uold
%  xnew = sx xold
%  ynew = sy yold
%

su = diag( [1/(535), 1/1] )% n delta_flap % 12 kRPM
sx = diag([1/0.5, 1/0.1, 1/1, 1/10, 1/10, 1/60])% phi theta w p q r
sy = diag( [1/0.5, 1/0.1, 1/1, 1/10, 1/10, 1/60] )% phi 

%
% Scaled F404 Dynamics
%
%
% u = [ W_f/110    A_8/22 ]
% x = [ N_2/250  N_25/350  T_45/28 ]
% y = [ N_2/250            T_45/28 ]inv(sy)
%
ap = sx*ap*inv(sx)
bp = sx*bp*inv(su)
cp = sy*cp*inv(sx)
dp = sy*dp*inv(su)
    
%
% F404 FREQUENCY RESPONSE: Scaled Singular Values
%
sv = sigma(ss(ap, bp, cp, dp),w);
sv = 20*log10(sv);
figure(11)
semilogx(w, sv)
%clear sv
title('Outputs: N_2/250, T_45/350; Inputs: W_f/110, A_8/22')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Augment Plant with Integrators at Plant Input and Plot Singular Values
%
[ns nc] = size(bp);                      % ns = number of inputs;  nc = number of controls;   
a = [ ap             bp
      0*ones(nc,ns)    0*ones(nc,nc) ]

b = [ 0*ones(ns,nc)
      eye(nc)      ]

c = [ cp  0*ones(nc,nc) ]

d = 0*ones(nc,nc)
sv = sigma(ss(a, b, c, d),w);
sv = 20*log10(sv);
figure(12)
semilogx(w, sv)
%clear sv
title('Design Plant Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%return


%
%*********************************************************************************************
%


%
% Design of Target Loop Singular Values Using Kalman Filter
%
ll =  inv(cp*inv(-ap)*bp + dp);     % Choose ll and lh to match singular values at all frequencies
lh = -inv(ap)*bp*ll;
l = [lh 
     ll];                           % ll, lh - for low and high frequency loop shaping

sv = sigma(ss(a, l, c, d),w);
sv = 20*log10(sv);
figure(13)
semilogx(w, sv)
%clear sv
title('Filter Open Loop (G_{FOL}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


pnint = eye(nc)                                    % Process Noise Intensity Matrix
mu = 0.0015;%0.01;                                         % Measurement Noise Intesity; Used to adjust Kalman Filter Bandwidth
                                                   % Small mu - expensive sensor   - large bandwidth
                                                   % Large mu - inexpensive sensor - small bandwidth
mnint = mu*eye(nc)                                 % Measurement Noise Intensity Matrix 
% sysKal=ss(a, [b l], c, [d 0*ones(nc,nc)]);
% [kest, h, sig]= kalman(sysKal,pnint, mnint);  % Compute Filter Gain Matrix h
%[sig, poles, g1, rr] = care(a',c',l*l', mnint);                          
[sig, poles, g1] = care(a',c',l*l', mnint);                          
% Alternate Method for Computing h
h = g1';
sv = sigma(ss(a, h, c, d),w);
tsv = 20*log10(sv);
figure(15)
semilogx(w, tsv)
%clear sv
title('Target Loop (G_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

tolpoles = eig(a)                           % Target Open Loop Poles
%targzeros = tzero(a,h,c,0*ones(nc,nc))      % Target Open Loop Zeros
[targpoles,targzeros] = pzmap(ss(a,h,c,0*ones(nc,nc)))      % Target Open Loop Zeros
tclpoles = eig(a-h*c)                       % Target Closed Loop Poles

sv = sigma(ss(a-h*c, h, -c, eye(nc)),w);
sv = 20*log10(sv);
figure(16)
semilogx(w, sv)
%clear sv
title('Target Sensitivity (S_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


sv = sigma(ss(a-h*c, h, c, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(17)
semilogx(w, sv, w, 20*log10(10./w))
%clear sv
title('Target Complementary (T_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Recover Target Loop By Solving Cheap LQR Problem
%
q = c'*c;                                            % State Weighting Matrix
rho = 1e-6;%1e-3                                     % Cheap control recovery parameter;
                                                     % The smaller the parameter, the better the recovery.
r = rho*eye(nc)                                      % Control Weigthing Matrix
%[k, poles, g, rr] = care(a,b,q,r);                   % Compute Control Gain Matrix G
[k, poles, g] = care(a,b,q,r);                   % Compute Control Gain Matrix G


%
% Compensator Analysis
%
ak = [ a-b*g-h*c  0*ones(ns+nc,nc)
       g          0*ones(nc,nc) ]

bk = [ h
       0*ones(nc,nc) ]

ck = [0*ones(nc, ns+nc) eye(nc,nc) ]

dk = 0*eye(2);

%cpoles = eig(ak)                               % Compensator Poles
%czeros = tzero(a, h, g, 0*ones(nc,nc))         % Compensator Zeros
[cpoles, czeros] = pzmap(ss(a, h, g, 0*ones(nc,nc)))         % Compensator Zeros
%zerocheck = tzero(ak, bk, ck, 0*ones(nc,nc))   % Check Compensator Zeros
[polecheck, zerocheck] = pzmap(ss(ak, bk, ck, 0*ones(nc,nc)))   % Check Compensator Zeros

sv = sigma(ss(ak, bk, ck, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(18)
semilogx(w, sv)
%clear sv
title('Compensator Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Open Loop Analysis
%
al = [ ap                     bp*ck
       0*ones(ns+nc+nc,ns)    ak    ]

bl = [ 0*ones(ns,nc)
       bk ]
    
cl = [ cp  0*ones(nc,ns+nc+nc) ]
    
%olpoles = eig(al)                          % Open Loop Poles
%olzeros = tzero(al,bl,cl,0*ones(nc,nc))    % Open Loop Zeros
[olpoles, olzeros] = pzmap(ss(al,bl,cl,0*ones(nc,nc)))    % Open Loop Zeros    
sv = sigma(ss(al, bl, cl, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(19)
semilogx(w, sv, w, tsv)
%clear sv
title('Open Loop Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%
% Closed Loop Analysis
%
clpoles = eig(al-bl*cl)           % Closed Loop Poles
clpkf = eig(a - h*c)              % Closed Loop Poles Due to Kalman Filter
clpreg = eig(a - b*g)             % Closed Loop Poles Due to Regulator


sv = sigma(ss(al-bl*cl, bl, -cl, eye(nc)),w);
sv = 20*log10(sv);
figure(20)
semilogx(w, sv)
%clear sv
title('Sensitivity Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

sv = sigma(ss(al-bl*cl, bl, cl, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(21)
semilogx(w, sv)
%clear sv
title('Complementary Sensitivity Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%
% Step Response in Closed Loop 
%

[y,t] = step(ss(al-bl*cl, bl, cl, 0*eye(nc)));
figure(22)
plot(t,y(:,1,1))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 1 response caused by input 1')
%return

%
figure(23)
plot(t,y(:,1,2))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 1 response caused by input 2')

figure(24)
plot(t,y(:,2,1))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 2 response caused by input 1')
%return

%
figure(25)
plot(t,y(:,2,2))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 2 response caused by input 2')

apo = [
   -0.0000  -41.1497         0         0         0    1.0000   -0.0058    0.0652;
   40.9742         0         0         0         0         0    0.9961    0.0883;
         0   -9.7861   -0.0003  -17.2703   -0.1914         0   -0.2965   -0.0211;
    9.7478    0.0566   17.2235         0    1.1317         0         0    0.0068;
    0.8645   -0.6380    1.5308    0.6222   -2.7477    0.0099    0.4300    0.4209;
         0         0    0.0366   19.2609  -30.1487   -0.0080   45.6063    1.1551;
         0         0    0.0018    0.9980   -1.1555  -40.8076   -0.0793    3.1405;
         0         0    0.0019    0.2725   -8.3410    0.5099    2.0407    0.0791];


bpo = [
         0         0;
         0         0;
         0    0.4436;
   -0.0002         0;
   -0.0001   -4.4403;
   -0.0002  -48.7721;
   -0.0003   -3.1051;
    0.0003   -2.7288]; 
            
     
 cpo =[0     0     1     0     0     0     0    0;% vx
      0     0     0     0     1     0     0    0];% vz

dpo = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]')
