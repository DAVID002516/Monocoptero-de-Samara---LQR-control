//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: linear_simulation_v3.h
//
// Code generated for Simulink model 'linear_simulation_v3'.
//
// Model version                  : 1.15
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Thu Dec  5 07:13:51 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Custom Processor->Custom Processor
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#ifndef RTW_HEADER_linear_simulation_v3_h_
#define RTW_HEADER_linear_simulation_v3_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include <cstring>
#include <stddef.h>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef rtmGetTStart
#define rtmGetTStart(rtm)              ((rtm)->Timing.tStart)
#endif

#ifndef ODE3_INTG
#define ODE3_INTG

// ODE3 Integration Data
struct ODE3_IntgData {
  real_T *y;                           // output
  real_T *f[3];                        // derivatives
};

#endif

extern "C"
{
  static real_T rtGetNaN(void);
  static real32_T rtGetNaNF(void);
}                                      // extern "C"

#define NOT_USING_NONFINITE_LITERALS   1

extern "C"
{
  extern real_T rtInf;
  extern real_T rtMinusInf;
  extern real_T rtNaN;
  extern real32_T rtInfF;
  extern real32_T rtMinusInfF;
  extern real32_T rtNaNF;
  static void rt_InitInfAndNaN(size_t realSize);
  static boolean_T rtIsInf(real_T value);
  static boolean_T rtIsInfF(real32_T value);
  static boolean_T rtIsNaN(real_T value);
  static boolean_T rtIsNaNF(real32_T value);
  struct BigEndianIEEEDouble {
    struct {
      uint32_T wordH;
      uint32_T wordL;
    } words;
  };

  struct LittleEndianIEEEDouble {
    struct {
      uint32_T wordL;
      uint32_T wordH;
    } words;
  };

  struct IEEESingle {
    union {
      real32_T wordLreal;
      uint32_T wordLuint;
    } wordL;
  };
}                                      // extern "C"

extern "C"
{
  static real_T rtGetInf(void);
  static real32_T rtGetInfF(void);
  static real_T rtGetMinusInf(void);
  static real32_T rtGetMinusInfF(void);
}                                      // extern "C"

// Class declaration for model linear_simulation_v3
class linear_simulation_v3 final
{
  // public data and function members
 public:
  // Block signals and states (default storage) for system '<Root>'
  struct DW {
    real_T ZOH1[6];                    // '<Root>/ZOH1'
    real_T ZOH2[2];                    // '<Root>/ZOH2'
    real_T Sum5[2];                    // '<Root>/Sum5'
    real_T R_2D[4];                    // '<S3>/Rotation Matrix'
    real_T last_ref[2];                // '<Root>/Yaw Setpoint Generator1'
    boolean_T last_ref_not_empty;      // '<Root>/Yaw Setpoint Generator1'
  };

  // Continuous states (default storage)
  struct X {
    real_T StateSpace1_CSTATE[12];     // '<Root>/State-Space1'
  };

  // State derivatives (default storage)
  struct XDot {
    real_T StateSpace1_CSTATE[12];     // '<Root>/State-Space1'
  };

  // State disabled
  struct XDis {
    boolean_T StateSpace1_CSTATE[12];  // '<Root>/State-Space1'
  };

  // Constant parameters (default storage)
  struct ConstP {
    // Expression: [-535 0.071]
    //  Referenced by: '<Root>/Actuator Bias1'

    real_T ActuatorBias1_Value[2];

    // Computed Parameter: StateSpace1_A_pr
    //  Referenced by: '<Root>/State-Space1'

    real_T StateSpace1_A_pr[64];

    // Computed Parameter: StateSpace1_B_pr
    //  Referenced by: '<Root>/State-Space1'

    real_T StateSpace1_B_pr[10];

    // Expression: [-0.088454;0.065357;0;-0.016139;-0.023368;-0.0031329;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50]
    //  Referenced by: '<Root>/State-Space1'

    real_T StateSpace1_InitialCondition[12];

    // Expression: K_hov
    //  Referenced by: '<Root>/Hovering Controller'

    real_T HoveringController_Gain[12];

    // Computed Parameter: StateSpace1_A_ir
    //  Referenced by: '<Root>/State-Space1'

    uint32_T StateSpace1_A_ir[64];

    // Computed Parameter: StateSpace1_A_jc
    //  Referenced by: '<Root>/State-Space1'

    uint32_T StateSpace1_A_jc[13];

    // Computed Parameter: StateSpace1_B_ir
    //  Referenced by: '<Root>/State-Space1'

    uint32_T StateSpace1_B_ir[10];
  };

  // Real-time Model Data Structure
  struct RT_MODEL {
    const char_T *errorStatus;
    RTWSolverInfo solverInfo;
    X *contStates;
    int_T *periodicContStateIndices;
    real_T *periodicContStateRanges;
    real_T *derivs;
    XDis *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T CTOutputIncnstWithState;
    real_T odeY[12];
    real_T odeF[3][12];
    ODE3_IntgData intgData;

    //
    //  Sizes:
    //  The following substructure contains sizes information
    //  for many of the model attributes such as inputs, outputs,
    //  dwork, sample times, etc.

    struct {
      int_T numContStates;
      int_T numPeriodicContStates;
      int_T numSampTimes;
    } Sizes;

    //
    //  Timing:
    //  The following substructure contains information regarding
    //  the timing information for the model.

    struct {
      uint32_T clockTick0;
      time_T stepSize0;
      uint32_T clockTick1;
      time_T tStart;
      SimTimeStep simTimeStep;
      boolean_T stopRequestedFlag;
      time_T *t;
      time_T tArray[2];
    } Timing;
  };

  // Copy Constructor
  linear_simulation_v3(linear_simulation_v3 const&) = delete;

  // Assignment Operator
  linear_simulation_v3& operator= (linear_simulation_v3 const&) & = delete;

  // Move Constructor
  linear_simulation_v3(linear_simulation_v3 &&) = delete;

  // Move Assignment Operator
  linear_simulation_v3& operator= (linear_simulation_v3 &&) = delete;

  // Real-Time Model get method
  linear_simulation_v3::RT_MODEL * getRTM();

  // model initialize function
  void initialize();

  // model step function
  void step();

  // Constructor
  linear_simulation_v3();

  // Destructor
  ~linear_simulation_v3();

  // private data and function members
 private:
  // Block states
  DW rtDW;

  // Block continuous states
  X rtX;

  // Block Continuous state disabled vector
  XDis rtXDis;

  // Continuous states update member function
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  // Derivatives member function
  void linear_simulation_v3_derivatives();

  // Real-Time Model
  RT_MODEL rtM;
};

// Constant parameters (default storage)
extern const linear_simulation_v3::ConstP rtConstP;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<Root>/A. Speed' : Unused code path elimination
//  Block '<Root>/Angles1' : Unused code path elimination
//  Block '<Root>/Clock2' : Unused code path elimination
//  Block '<Root>/Gain1' : Unused code path elimination
//  Block '<Root>/Gain2' : Unused code path elimination
//  Block '<Root>/Gain3' : Unused code path elimination
//  Block '<Root>/Gain4' : Unused code path elimination
//  Block '<Root>/Gain5' : Unused code path elimination
//  Block '<Root>/L. Speed' : Unused code path elimination
//  Block '<Root>/Position' : Unused code path elimination
//  Block '<Root>/Scope1' : Unused code path elimination
//  Block '<Root>/Scope2' : Unused code path elimination
//  Block '<Root>/Scope3' : Unused code path elimination
//  Block '<Root>/Scope4' : Unused code path elimination
//  Block '<Root>/Scope5' : Unused code path elimination
//  Block '<Root>/Total export' : Unused code path elimination
//  Block '<Root>/ZOH4' : Unused code path elimination


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'linear_simulation_v3'
//  '<S1>'   : 'linear_simulation_v3/3D Plotter'
//  '<S2>'   : 'linear_simulation_v3/3D Plotter1'
//  '<S3>'   : 'linear_simulation_v3/Position Error Rotation'
//  '<S4>'   : 'linear_simulation_v3/Yaw Setpoint Generator1'
//  '<S5>'   : 'linear_simulation_v3/Position Error Rotation/Rotation Matrix'

#endif                                 // RTW_HEADER_linear_simulation_v3_h_

//
// File trailer for generated code.
//
// [EOF]
//
