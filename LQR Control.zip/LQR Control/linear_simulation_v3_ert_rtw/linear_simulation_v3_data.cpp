//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: linear_simulation_v3_data.cpp
//
// Code generated for Simulink model 'linear_simulation_v3'.
//
// Model version                  : 1.15
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Thu Dec  5 07:13:51 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Custom Processor->Custom Processor
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "linear_simulation_v3.h"

// Constant parameters (default storage)
const linear_simulation_v3::ConstP rtConstP{
  // Expression: [-535 0.071]
  //  Referenced by: '<Root>/Actuator Bias1'

  { -535.0, 0.071 },

  // Computed Parameter: StateSpace1_A_pr
  //  Referenced by: '<Root>/State-Space1'

  { -4.2705050873337314E-7, 40.974188218475319, -6.5387721406295896E-6,
    -9.7478033123770729, -0.86448798749552225, -0.0015202087250543173,
    -0.002064298729358427, -0.023226946854663311, -41.1497106179595,
    -2.6875073848568718, 9.7860619708371814, -0.056580926865649417,
    0.63799584759544814, 0.0031139372833379753, 0.015969722753993665,
    0.023276642686539617, -0.015969722753993665, -0.00046474576179633686,
    40.814000000013039, 3.6291824489890132, 0.032878494593205687,
    0.0026539374119209924, 0.00087517565361672212, 0.99786499141919194,
    -0.065310480790913061, -40.880310969310813, 3.3720527459154255,
    20.774415009655058, 1.7594216133547889, 0.10821171269776642,
    -0.0057694429352181942, 0.996090494973032, -0.088150095594528466,
    0.40142520589142805, 2.681799999998475, -10.12296774375136,
    -34.687360758776776, -1.5183706840070954, -7.8308471175987506,
    0.065055149137833723, 0.0883386994760258, 0.99396383321982285, 1.0,
    0.02336800000000494, -0.0079639569140681488, -40.807646168977953,
    0.50993873324114247, -0.0057817871002896482, 0.996090494973032,
    -0.088527706889863111, -1.0588387220996083, 2.03862611434306,
    47.842631887760945, -0.43789211270268424, 2.2515161423725658,
    0.065194339612162366, 0.0883386994760258, 0.99822170688275946,
    -0.04160351659686512, 0.016139000000009673, 1.6648095051277778,
    2.2454411088619963, 3.3848260135855526, 0.043454477369323286 },

  // Computed Parameter: StateSpace1_B_pr
  //  Referenced by: '<Root>/State-Space1'

  { 0.036082675982811452, 0.014579504367645768, 0.028314691202865561,
    0.044755544199233555, -0.046573860211196916, 1.0578309972006537,
    -18.953554454201367, -65.090423594694585, -7.61400833769585,
    -2.0046002184826648 },

  // Expression: [-0.088454;0.065357;0;-0.016139;-0.023368;-0.0031329;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50]
  //  Referenced by: '<Root>/State-Space1'

  { -0.088454, 0.065357, 0.0, -0.016139, -0.023368, -0.0031329, 2.6818, 3.6196,
    -40.814, 2.6319E-10, 1.4418000000000001E-11, -50.0 },

  // Expression: K_hov
  //  Referenced by: '<Root>/Hovering Controller'

  { 9.69721743862682, -0.046239205684985761, 1.3758622056028891,
    -0.016450958816534526, 1.8400627316485914, -0.0064174135155220594,
    0.18035371805010278, -0.0032931035793555413, 0.32794199528007434,
    -0.00080857242031823619, -3.0365365552018466, 0.009263035584314093 },

  // Computed Parameter: StateSpace1_A_ir
  //  Referenced by: '<Root>/State-Space1'

  { 0U, 1U, 2U, 4U, 5U, 9U, 10U, 11U, 0U, 2U, 3U, 4U, 5U, 9U, 11U, 9U, 10U, 3U,
    4U, 5U, 6U, 7U, 8U, 9U, 11U, 3U, 5U, 6U, 7U, 8U, 9U, 10U, 11U, 3U, 4U, 5U,
    6U, 7U, 8U, 9U, 10U, 11U, 0U, 5U, 6U, 7U, 8U, 0U, 1U, 2U, 3U, 5U, 6U, 7U, 8U,
    0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U, 8U },

  // Computed Parameter: StateSpace1_A_jc
  //  Referenced by: '<Root>/State-Space1'

  { 0U, 8U, 15U, 17U, 25U, 33U, 42U, 47U, 55U, 64U, 64U, 64U, 64U },

  // Computed Parameter: StateSpace1_B_ir
  //  Referenced by: '<Root>/State-Space1'

  { 4U, 5U, 6U, 7U, 8U, 3U, 5U, 6U, 7U, 8U }
};

//
// File trailer for generated code.
//
// [EOF]
//
