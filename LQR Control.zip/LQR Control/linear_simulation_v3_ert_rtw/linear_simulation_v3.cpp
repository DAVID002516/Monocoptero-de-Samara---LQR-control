//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: linear_simulation_v3.cpp
//
// Code generated for Simulink model 'linear_simulation_v3'.
//
// Model version                  : 1.15
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Thu Dec  5 07:13:51 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: Custom Processor->Custom Processor
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "linear_simulation_v3.h"
#include <cstring>
#include <cmath>
#include "rtwtypes.h"
#include <stddef.h>
#define NumBitsPerChar                 8U

// Private macros used by the generated code to access rtModel
#ifndef rtmIsMajorTimeStep
#define rtmIsMajorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
#define rtmIsMinorTimeStep(rtm)        (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmSetTPtr
#define rtmSetTPtr(rtm, val)           ((rtm)->Timing.t = (val))
#endif

extern real_T rt_atan2d_snf(real_T u0, real_T u1);

// private model entry point functions
extern void linear_simulation_v3_derivatives();

//===========*
//  Constants *
// ===========
#define RT_PI                          3.14159265358979323846
#define RT_PIF                         3.1415927F
#define RT_LN_10                       2.30258509299404568402
#define RT_LN_10F                      2.3025851F
#define RT_LOG10E                      0.43429448190325182765
#define RT_LOG10EF                     0.43429449F
#define RT_E                           2.7182818284590452354
#define RT_EF                          2.7182817F

//
//  UNUSED_PARAMETER(x)
//    Used to specify that a function parameter (argument) is required but not
//    accessed by the function body.

#ifndef UNUSED_PARAMETER
#if defined(__LCC__)
#define UNUSED_PARAMETER(x)                                      // do nothing
#else

//
//  This is the semi-ANSI standard way of indicating that an
//  unused function parameter is required.

#define UNUSED_PARAMETER(x)            (void) (x)
#endif
#endif

extern "C"
{
  real_T rtInf;
  real_T rtMinusInf;
  real_T rtNaN;
  real32_T rtInfF;
  real32_T rtMinusInfF;
  real32_T rtNaNF;
}

extern "C"
{
  //
  // Initialize rtNaN needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetNaN(void)
  {
    size_t bitsPerReal{ sizeof(real_T) * (NumBitsPerChar) };

    real_T nan{ 0.0 };

    if (bitsPerReal == 32U) {
      nan = rtGetNaNF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF80000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      nan = tmpVal.fltVal;
    }

    return nan;
  }

  //
  // Initialize rtNaNF needed by the generated code.
  // NaN is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetNaNF(void)
  {
    IEEESingle nanF{ { 0.0F } };

    nanF.wordL.wordLuint = 0xFFC00000U;
    return nanF.wordL.wordLreal;
  }
}

extern "C"
{
  //
  // Initialize the rtInf, rtMinusInf, and rtNaN needed by the
  // generated code. NaN is initialized as non-signaling. Assumes IEEE.
  //
  static void rt_InitInfAndNaN(size_t realSize)
  {
    (void) (realSize);
    rtNaN = rtGetNaN();
    rtNaNF = rtGetNaNF();
    rtInf = rtGetInf();
    rtInfF = rtGetInfF();
    rtMinusInf = rtGetMinusInf();
    rtMinusInfF = rtGetMinusInfF();
  }

  // Test if value is infinite
  static boolean_T rtIsInf(real_T value)
  {
    return (boolean_T)((value==rtInf || value==rtMinusInf) ? 1U : 0U);
  }

  // Test if single-precision value is infinite
  static boolean_T rtIsInfF(real32_T value)
  {
    return (boolean_T)(((value)==rtInfF || (value)==rtMinusInfF) ? 1U : 0U);
  }

  // Test if value is not a number
  static boolean_T rtIsNaN(real_T value)
  {
    boolean_T result{ (boolean_T) 0 };

    size_t bitsPerReal{ sizeof(real_T) * (NumBitsPerChar) };

    if (bitsPerReal == 32U) {
      result = rtIsNaNF((real32_T)value);
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.fltVal = value;
      result = (boolean_T)((tmpVal.bitVal.words.wordH & 0x7FF00000) ==
                           0x7FF00000 &&
                           ( (tmpVal.bitVal.words.wordH & 0x000FFFFF) != 0 ||
                            (tmpVal.bitVal.words.wordL != 0) ));
    }

    return result;
  }

  // Test if single-precision value is not a number
  static boolean_T rtIsNaNF(real32_T value)
  {
    IEEESingle tmp;
    tmp.wordL.wordLreal = value;
    return (boolean_T)( (tmp.wordL.wordLuint & 0x7F800000) == 0x7F800000 &&
                       (tmp.wordL.wordLuint & 0x007FFFFF) != 0 );
  }
}

extern "C"
{
  //
  // Initialize rtInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetInf(void)
  {
    size_t bitsPerReal{ sizeof(real_T) * (NumBitsPerChar) };

    real_T inf{ 0.0 };

    if (bitsPerReal == 32U) {
      inf = rtGetInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0x7FF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      inf = tmpVal.fltVal;
    }

    return inf;
  }

  //
  // Initialize rtInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetInfF(void)
  {
    IEEESingle infF;
    infF.wordL.wordLuint = 0x7F800000U;
    return infF.wordL.wordLreal;
  }

  //
  // Initialize rtMinusInf needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real_T rtGetMinusInf(void)
  {
    size_t bitsPerReal{ sizeof(real_T) * (NumBitsPerChar) };

    real_T minf{ 0.0 };

    if (bitsPerReal == 32U) {
      minf = rtGetMinusInfF();
    } else {
      union {
        LittleEndianIEEEDouble bitVal;
        real_T fltVal;
      } tmpVal;

      tmpVal.bitVal.words.wordH = 0xFFF00000U;
      tmpVal.bitVal.words.wordL = 0x00000000U;
      minf = tmpVal.fltVal;
    }

    return minf;
  }

  //
  // Initialize rtMinusInfF needed by the generated code.
  // Inf is initialized as non-signaling. Assumes IEEE.
  //
  static real32_T rtGetMinusInfF(void)
  {
    IEEESingle minfF;
    minfF.wordL.wordLuint = 0xFF800000U;
    return minfF.wordL.wordLreal;
  }
}

//
// This function updates continuous states using the ODE3 fixed-step
// solver algorithm
//
void linear_simulation_v3::rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  // Solver Matrices
  static const real_T rt_ODE3_A[3]{
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3]{
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t { rtsiGetT(si) };

  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE3_IntgData *id { static_cast<ODE3_IntgData *>(rtsiGetSolverData(si)) };

  real_T *y { id->y };

  real_T *f0 { id->f[0] };

  real_T *f1 { id->f[1] };

  real_T *f2 { id->f[2] };

  real_T hB[3];
  int_T i;
  int_T nXc { 12 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  // Save the state values at time t in y, we'll use x as ynew.
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  // Assumes that rtsiSetT and ModelOutputs are up-to-date
  // f0 = f(t,y)
  rtsiSetdX(si, f0);
  linear_simulation_v3_derivatives();

  // f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*));
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  this->step();
  linear_simulation_v3_derivatives();

  // f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*));
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  this->step();
  linear_simulation_v3_derivatives();

  // tnew = t + hA(3);
  // ynew = y + f*hB(:,3);
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = (rtNaN);
  } else if (std::isinf(u0) && std::isinf(u1)) {
    int32_T tmp;
    int32_T tmp_0;
    if (u0 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u1 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(tmp), static_cast<real_T>(tmp_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

// Model step function
void linear_simulation_v3::step()
{
  real_T StateSpace1[12];
  real_T rtb_HoveringController_0[6];
  real_T R_2D_tmp;
  real_T R_2D_tmp_0;
  real_T R_2D_tmp_1;
  real_T rtb_Clock1;
  real_T rtb_ZOH3_idx_2;
  real_T y;
  int32_T ri;
  int_T iy;
  boolean_T rtb_Clock1_0;
  if (rtmIsMajorTimeStep((&rtM))) {
    // set solver stop time
    rtsiSetSolverStopTime(&(&rtM)->solverInfo,(((&rtM)->Timing.clockTick0+1)*
      (&rtM)->Timing.stepSize0));
  }                                    // end MajorTimeStep

  // Update absolute time of base rate at minor time step
  if (rtmIsMinorTimeStep((&rtM))) {
    (&rtM)->Timing.t[0] = rtsiGetT(&(&rtM)->solverInfo);
  }

  // StateSpace: '<Root>/State-Space1'
  std::memset(&StateSpace1[0], 0, 12U * sizeof(real_T));
  for (iy = 0; iy < 12; iy++) {
    for (ri = iy; static_cast<uint32_T>(ri) < static_cast<uint32_T>(iy) + 1U; ri
         = static_cast<int32_T>(static_cast<uint32_T>(ri) + 1U)) {
      StateSpace1[static_cast<uint32_T>(ri)] += rtX.StateSpace1_CSTATE[
        static_cast<uint32_T>(iy)];
    }
  }

  // End of StateSpace: '<Root>/State-Space1'
  if (rtmIsMajorTimeStep((&rtM))) {
    // ZeroOrderHold: '<Root>/ZOH1'
    rtDW.ZOH1[0] = StateSpace1[0];
    rtDW.ZOH1[1] = StateSpace1[1];
    rtDW.ZOH1[2] = StateSpace1[5];
    rtDW.ZOH1[3] = StateSpace1[6];
    rtDW.ZOH1[4] = StateSpace1[7];
    rtDW.ZOH1[5] = StateSpace1[8];

    // MATLAB Function: '<Root>/Yaw Setpoint Generator1'
    if (!rtDW.last_ref_not_empty) {
      rtDW.last_ref[0] = StateSpace1[3];
      rtDW.last_ref[1] = StateSpace1[4];
      rtDW.last_ref_not_empty = true;
    }

    // ZeroOrderHold: '<Root>/ZOH3' incorporates:
    //   Gain: '<Root>/Gain'
    //   MATLAB Function: '<Root>/Yaw Setpoint Generator1'

    rtb_ZOH3_idx_2 = rt_atan2d_snf(StateSpace1[4] - rtDW.last_ref[1],
      StateSpace1[3] - rtDW.last_ref[0]) * 57.295779513082323;

    // MATLAB Function: '<S3>/Rotation Matrix' incorporates:
    //   ZeroOrderHold: '<Root>/ZOH3'

    y = std::cos(rtb_ZOH3_idx_2);
    rtb_ZOH3_idx_2 = std::sin(rtb_ZOH3_idx_2);

    // MATLAB Function: '<Root>/Yaw Setpoint Generator1'
    rtDW.last_ref[0] = StateSpace1[3];

    // ZeroOrderHold: '<Root>/ZOH2' incorporates:
    //   MATLAB Function: '<Root>/Yaw Setpoint Generator1'

    rtDW.ZOH2[0] = StateSpace1[3];

    // MATLAB Function: '<Root>/Yaw Setpoint Generator1'
    rtDW.last_ref[1] = StateSpace1[4];

    // ZeroOrderHold: '<Root>/ZOH2' incorporates:
    //   MATLAB Function: '<Root>/Yaw Setpoint Generator1'

    rtDW.ZOH2[1] = StateSpace1[4];

    // MATLAB Function: '<S3>/Rotation Matrix' incorporates:
    //   ZeroOrderHold: '<Root>/ZOH3'

    rtb_Clock1 = std::cos(StateSpace1[1]);
    R_2D_tmp = std::cos(StateSpace1[0]);
    R_2D_tmp_0 = std::sin(StateSpace1[0]);
    R_2D_tmp_1 = std::sin(StateSpace1[1]);
    rtDW.R_2D[0] = rtb_Clock1 * y;
    rtDW.R_2D[2] = rtb_Clock1 * rtb_ZOH3_idx_2;
    rtDW.R_2D[1] = y * R_2D_tmp_0 * R_2D_tmp_1 - R_2D_tmp * rtb_ZOH3_idx_2;
    rtDW.R_2D[3] = R_2D_tmp_0 * R_2D_tmp_1 * rtb_ZOH3_idx_2 + R_2D_tmp * y;
  }

  // Product: '<S3>/Matrix Multiply' incorporates:
  //   Step: '<Root>/u'
  //   Step: '<Root>/v'
  //   Sum: '<Root>/Sum3'

  y = (0.0 - rtDW.ZOH2[0]) * rtDW.R_2D[0] + (0.0 - rtDW.ZOH2[1]) * rtDW.R_2D[2];
  rtb_ZOH3_idx_2 = (0.0 - rtDW.ZOH2[0]) * rtDW.R_2D[1] + (0.0 - rtDW.ZOH2[1]) *
    rtDW.R_2D[3];

  // Sum: '<Root>/Sum4' incorporates:
  //   Gain: '<Root>/Position Controller'
  //   Product: '<S3>/Matrix Multiply'
  //   Step: '<Root>/re'
  //   Step: '<Root>/w'

  rtb_HoveringController_0[0] = (-3.4462627004783963E-6 * y +
    -0.0998537040351584 * rtb_ZOH3_idx_2) - rtDW.ZOH1[0];
  rtb_HoveringController_0[1] = (0.10009671149042958 * y +
    -0.0005761390135642717 * rtb_ZOH3_idx_2) - rtDW.ZOH1[1];
  rtb_HoveringController_0[2] = 0.0 - rtDW.ZOH1[2];
  rtb_HoveringController_0[3] = 0.0 - rtDW.ZOH1[3];
  rtb_HoveringController_0[4] = 0.0 - rtDW.ZOH1[4];
  if ((&rtM)->Timing.t[0] < 1.0) {
    iy = 0;
  } else {
    iy = -25;
  }

  rtb_HoveringController_0[5] = static_cast<real_T>(iy) - rtDW.ZOH1[5];

  // End of Sum: '<Root>/Sum4'

  // Switch: '<Root>/Switch1' incorporates:
  //   Clock: '<Root>/Clock1'

  rtb_Clock1_0 = ((&rtM)->Timing.t[0] > 20.0);
  for (iy = 0; iy < 2; iy++) {
    // Sum: '<Root>/Sum5' incorporates:
    //   Gain: '<Root>/Hovering Controller'

    y = 0.0;
    for (ri = 0; ri < 6; ri++) {
      y += rtConstP.HoveringController_Gain[(ri << 1) + iy] *
        rtb_HoveringController_0[ri];
    }

    // Sum: '<Root>/Sum5' incorporates:
    //   Constant: '<Root>/Actuator Bias1'
    //   Gain: '<Root>/Hovering Controller'
    //   Switch: '<Root>/Switch1'

    if (rtb_Clock1_0) {
      rtb_ZOH3_idx_2 = rtConstP.ActuatorBias1_Value[iy];
    } else {
      rtb_ZOH3_idx_2 = 0.0;
    }

    // Sum: '<Root>/Sum5' incorporates:
    //   Gain: '<Root>/Hovering Controller'
    //   Switch: '<Root>/Switch1'

    rtDW.Sum5[iy] = y + rtb_ZOH3_idx_2;
  }

  if (rtmIsMajorTimeStep((&rtM))) {
    rt_ertODEUpdateContinuousStates(&(&rtM)->solverInfo);

    // Update absolute time for base rate
    // The "clockTick0" counts the number of times the code of this task has
    //  been executed. The absolute time is the multiplication of "clockTick0"
    //  and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
    //  overflow during the application lifespan selected.

    ++(&rtM)->Timing.clockTick0;
    (&rtM)->Timing.t[0] = rtsiGetSolverStopTime(&(&rtM)->solverInfo);

    {
      // Update absolute timer for sample time: [0.005s, 0.0s]
      // The "clockTick1" counts the number of times the code of this task has
      //  been executed. The resolution of this integer timer is 0.005, which is the step size
      //  of the task. Size of "clockTick1" ensures timer will not overflow during the
      //  application lifespan selected.

      (&rtM)->Timing.clockTick1++;
    }
  }                                    // end MajorTimeStep
}

// Derivatives for root system: '<Root>'
void linear_simulation_v3::linear_simulation_v3_derivatives()
{
  linear_simulation_v3::XDot *_rtXdot;
  int_T is;
  uint32_T ri;
  _rtXdot = ((XDot *) (&rtM)->derivs);

  // Derivatives for StateSpace: '<Root>/State-Space1'
  std::memset(&_rtXdot->StateSpace1_CSTATE[0], 0, 12U * sizeof(real_T));
  for (is = 0; is < 12; is++) {
    for (ri = rtConstP.StateSpace1_A_jc[static_cast<uint32_T>(is)]; ri <
         rtConstP.StateSpace1_A_jc[static_cast<uint32_T>(is) + 1U]; ri++) {
      _rtXdot->StateSpace1_CSTATE[rtConstP.StateSpace1_A_ir[ri]] +=
        rtConstP.StateSpace1_A_pr[ri] * rtX.StateSpace1_CSTATE
        [static_cast<uint32_T>(is)];
    }
  }

  for (ri = 0U; ri < 5U; ri++) {
    _rtXdot->StateSpace1_CSTATE[rtConstP.StateSpace1_B_ir[ri]] +=
      rtConstP.StateSpace1_B_pr[ri] * rtDW.Sum5[0U];
  }

  while (ri < 10U) {
    _rtXdot->StateSpace1_CSTATE[rtConstP.StateSpace1_B_ir[ri]] +=
      rtConstP.StateSpace1_B_pr[ri] * rtDW.Sum5[1U];
    ri++;
  }

  // End of Derivatives for StateSpace: '<Root>/State-Space1'
}

// Model initialize function
void linear_simulation_v3::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  {
    // Setup solver object
    rtsiSetSimTimeStepPtr(&(&rtM)->solverInfo, &(&rtM)->Timing.simTimeStep);
    rtsiSetTPtr(&(&rtM)->solverInfo, &rtmGetTPtr((&rtM)));
    rtsiSetStepSizePtr(&(&rtM)->solverInfo, &(&rtM)->Timing.stepSize0);
    rtsiSetdXPtr(&(&rtM)->solverInfo, &(&rtM)->derivs);
    rtsiSetContStatesPtr(&(&rtM)->solverInfo, (real_T **) &(&rtM)->contStates);
    rtsiSetNumContStatesPtr(&(&rtM)->solverInfo, &(&rtM)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&rtM)->solverInfo, &(&rtM)
      ->periodicContStateRanges);
    rtsiSetContStateDisabledPtr(&(&rtM)->solverInfo, (boolean_T**) &(&rtM)
      ->contStateDisabled);
    rtsiSetErrorStatusPtr(&(&rtM)->solverInfo, (&rtmGetErrorStatus((&rtM))));
    rtsiSetRTModelPtr(&(&rtM)->solverInfo, (&rtM));
  }

  rtsiSetSimTimeStep(&(&rtM)->solverInfo, MAJOR_TIME_STEP);
  (&rtM)->intgData.y = (&rtM)->odeY;
  (&rtM)->intgData.f[0] = (&rtM)->odeF[0];
  (&rtM)->intgData.f[1] = (&rtM)->odeF[1];
  (&rtM)->intgData.f[2] = (&rtM)->odeF[2];
  (&rtM)->contStates = ((X *) &rtX);
  (&rtM)->contStateDisabled = ((XDis *) &rtXDis);
  (&rtM)->Timing.tStart = (0.0);
  rtsiSetSolverData(&(&rtM)->solverInfo, static_cast<void *>(&(&rtM)->intgData));
  rtsiSetIsMinorTimeStepWithModeChange(&(&rtM)->solverInfo, false);
  rtsiSetSolverName(&(&rtM)->solverInfo,"ode3");
  rtmSetTPtr((&rtM), &(&rtM)->Timing.tArray[0]);
  (&rtM)->Timing.stepSize0 = 0.005;

  // InitializeConditions for StateSpace: '<Root>/State-Space1'
  std::memcpy(&rtX.StateSpace1_CSTATE[0],
              &rtConstP.StateSpace1_InitialCondition[0], 12U * sizeof(real_T));
}

// Constructor
linear_simulation_v3::linear_simulation_v3() :
  rtDW(),
  rtX(),
  rtXDis(),
  rtM()
{
  // Currently there is no constructor body generated.
}

// Destructor
// Currently there is no destructor body generated.
linear_simulation_v3::~linear_simulation_v3() = default;

// Real-Time Model get method
linear_simulation_v3::RT_MODEL * linear_simulation_v3::getRTM()
{
  return (&rtM);
}

//
// File trailer for generated code.
//
// [EOF]
//
