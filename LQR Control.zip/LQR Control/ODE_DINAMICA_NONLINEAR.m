 %Tiempos 
 eps = 1e-10;
 options = odeset('RelTol', 1e-12, 'AbsTol',[1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12 1e-12]);
 t0 = 0; tf = 12;
 step = 0.4;
 t_segment = 50;
 Tu = linspace(t0, tf, t_segment);    % discretize time
 %condiciones
 init1 = [-0.088454;16.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init2 = [-0.088454;10.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init3 = [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init4 = [-0.088454;0.065357;0;-0.016139;-0.023368;-10.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init5 = [-0.088454;0.065357;0;-0.016139;-0.023368;-5.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init6 = [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init7 = [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-60.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init8 = [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-50.814;2.6319*10^(-10);1.4418*10^(-11);-50];
 init9 = [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];

 %initu = [0.1592;-535];
 initu = [-90;0.071578];
% x = x';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%========================

   % 1) start with assumed control u and move forward
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 
   [T1,X1] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init1,options);
   [T2,X2] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init2,options);
   [T3,X3] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init3,options);

   [T4,X4] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init4,options);
   [T5,X5] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init5,options);
   [T6,X6] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init6,options);
   
   [T7,X7] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init7,options);
   [T8,X8] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init8,options);
   [T9,X9] = ode113(@(t,x)nonlinear(t,x,initu), [t0 tf], init9,options);
   

figure(1);
subplot(3,1,1); plot(T1,X1(:,1)); ylabel('(grados)');
hold on
subplot(3,1,1); plot(T2,X2(:,1));
hold on
subplot(3,1,1); plot(T3,X3(:,1));
hold off
subplot(3,1,2); plot(T1,X1(:,2)); ylabel('(grados)');
hold on
subplot(3,1,2); plot(T2,X2(:,2));
hold on
subplot(3,1,2); plot(T3,X3(:,2));
hold off
%
subplot(3,1,3); plot(T1,180*sawtooth(-2*pi*20/pi*T1+pi)); ylabel('(grados)');% Frecuencia de 20/pi = 6.6363.. Hz
hold on
subplot(3,1,3); plot(T2,180*sawtooth(-2*pi*20/pi*T2+pi)); 
hold on
subplot(3,1,3); plot(T3,180*sawtooth(-2*pi*20/pi*T3+pi)); 
%}
%{
subplot(3,1,3); plot(T1,X1(:,3)*180/pi); ylabel('(grados)');% Frecuencia de 20/pi = 6.6363.. Hz
hold on
subplot(3,1,3); plot(T2,X2(:,3)*180/pi); 
hold on
subplot(3,1,3); plot(T3,X3(:,3)*180/pi); 
%}
xlabel('t');
hold off
legend('1','2','3')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
subplot(3,1,1); plot(T4,X4(:,4)); ylabel('u[m/s]');
hold on
subplot(3,1,1); plot(T5,X5(:,4));
hold on
subplot(3,1,1); plot(T6,X6(:,4));
hold off
subplot(3,1,2); plot(T4,X4(:,5)); ylabel('v[m/s]');
hold on
subplot(3,1,2); plot(T5,X5(:,5));
hold on
subplot(3,1,2); plot(T6,X6(:,5));
hold off
subplot(3,1,3); plot(T4,X4(:,6)); ylabel('w[m/s]');
hold on
subplot(3,1,3); plot(T5,X5(:,6)); 
hold on
subplot(3,1,3); plot(T6,X6(:,6));
xlabel('t');
hold off
legend('4','5','6')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3);
subplot(3,1,1); plot(T7,X7(:,7)); ylabel('p[rad/s]');
hold on
subplot(3,1,1); plot(T8,X8(:,7));
hold on
subplot(3,1,1); plot(T9,X9(:,7));
hold off
subplot(3,1,2); plot(T7,X7(:,8)); ylabel('q[rad/s]');
hold on
subplot(3,1,2); plot(T8,X8(:,8));
hold on
subplot(3,1,2); plot(T9,X9(:,8));
hold off
subplot(3,1,3); plot(T7,X7(:,9)); ylabel('r[rad/s]');
hold on
subplot(3,1,3); plot(T8,X8(:,9));
hold on
subplot(3,1,3); plot(T9,X9(:,9)); xlabel('t');
hold off
legend('7','8','9')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4)
plot3(X1(:,10),X1(:,11),-X1(:,12)); ylabel('y[m]');
hold on
plot3(X2(:,10),X2(:,11),-X2(:,12)); 
hold on
plot3(X3(:,10),X3(:,11),-X3(:,12));
hold on
plot3(X4(:,10),X4(:,11),-X4(:,12));
hold on
plot3(X5(:,10),X5(:,11),-X5(:,12));
hold on
plot3(X6(:,10),X6(:,11),-X6(:,12));
hold on
plot3(X7(:,10),X7(:,11),-X7(:,12));
hold on
plot3(X8(:,10),X8(:,11),-X8(:,12));
hold on
plot3(X9(:,10),X9(:,11),-X9(:,12));
xlabel('x[m]');
hold off
legend('1','2','3','4','5','6','7','8','9')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% State equations

function dx = nonlinear(t,x,u)

    dx = zeros(12,2);
        %Estados
phi = x(1); theta = x(2); psi = x(3); up = x(4); v = x(5); w = x(6);
pp = x(7); q = x(8); r = x(9); xp = x(10); y = x(11); z = x(12);
    %Entradas
    n = u(1); delta_f = u(2);
    
    %Salidas
    nw_dot(1) = dx(1); nw_dot(2) = dx(2); nw_dot(3) = dx(3); vc_dot(1) = dx(4); vc_dot(2) = dx(5); vc_dot(3) = dx(6);
    wc_dot(1) = dx(7); wc_dot(2) = dx(8); wc_dot(3) = dx(9); pw_dot(1) = dx(10); pw_dot(2) = dx(11); pw_dot(3) = dx(12);

% Constantes monocoptero
CL0 = 0.4;        % -
CLa = 6.8755;    % 1/rad
CLd = 1.17;        % 1/rad
CLq = 5.8;        % 1/rad
CD0 = 0.02;        % -
CDa = 0.063;       % 1/rad
CDd = 0.01;        % 1/rad
CM0 = -0.0950;
% -
CMa = -0.1;        % 1/rad
CMd = -0.1425;     % 1/rad
CMq = -2.5;        % 1/rad
m = 0.4220;        % kg
theta_p = 0.384;   % rad
rho = 1.1;         % kg/m^3
D = 0.12;          % m
Ctm = 0.4;         % -
Ix = 0.04;         % kg*m^2
Iy = 0.03;        % kg*m^2
Iz = 0.07;        % kg*m^2
g = 9.807;         % m/s^2

    % Transformation matrix from body angular velocity to Tait-Bryan rates
    W = [ 1, 0,      -sin(theta)         ;
      0, cos(phi),  cos(theta)*sin(phi)  ;
      0, -sin(phi), cos(theta)*cos(phi) ];

    Winv = inv(W);
  %
    % Rotation matrix from body to world frame, input: roll, pitch, yaw
    R = [cos(theta)*cos(psi), sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi), cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi) ;
     cos(theta)*sin(psi), sin(phi)*sin(theta)*sin(psi)+cos(phi)*cos(psi), cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi) ;
     -sin(theta),       sin(phi)*cos(theta),                      cos(phi)*cos(theta)                     ];

    % Matrix of mass inertia
    I = [Ix             -0.001           7.868*10^(-5)  ;
         -0.001          Iy             -7.185*10^(-5)  ;
         7.868*10^(-5)  -7.185*10^(-5)      Iz];
 
 %Definciones
 
    %Ra = 2*10^(-2);                  % Radio del disco
    Adisk = 0.019;      % Area del disco
    Rl = 0.4000; % Wingspan
    e = 0.08; %excentricidad en metros
    vi = sqrt(m*g/(2*rho*pi*Rl^2));    % Velocidad inducida
    lbe = (Rl/2+e);          % radio vector del blade element % Es de otro paper el valor
    vce = [up;v;w] + cross([pp;q;r],[lbe;0;0])+[0;0;vi]; % Vector de la velocidad del blade element
    T = rho*n^2*D^4*Ctm;    % Empuje 
    qb = 0.5*rho*(norm(vce))^2;% Presion dinamica
    a_inc = 0.1919; % angulo de incidencia 11 grados
    a_atk = atan(vce(3,1)/(vce(2,1))); % angulo de ataque Up/Ut
    a_eff = a_inc - a_atk; % angulo de efectivo de ataque
    c = 0.175; % Distancia media del chord en metros 150, 200
    S = 0.0190; % m^2 Area del pala % Es de  otro paper el valor
    CL = CL0 + CLa*a_eff + CLd*delta_f + CLq*q*c/(2*norm(vce)); %Coeficiente aerodinamico de sustentacion
    CD = CD0 + CDa*abs(a_eff) + CDd*abs(delta_f); % Coeficiente aerodinamico de arrastre
    dL =  qb*CL*S;
    dD =  qb*CD*S;
    
   

% Coeficiente aerodinamico del momento en el monocoptero
CM1 = CM0 + CMa*a_eff + CMd*delta_f + CMq*0.5*q*c/(norm(vce));
    
    % Fuerza aerodinamica
    dF1 = dD*cos(a_atk) + dL*sin(a_atk); % dA debe tenderer F1 = 0
    dF3 = dL*cos(a_atk) - dD*sin(a_atk);% dN
    dM = qb*c*CM1*S; % dM
    %dSp = 0.5*rho*norm(vce)*vce(2,1)*CD*S;% Fuerza de respuesta del aleron (valor minimo no considerado)
    
    
    Fa = [-dF1; 0; -dF3];
    Fm = [0;T*cos(theta_p);T*sin(theta_p)];
    
    %Corregir los torques
    
    CA = [0.0118830; lbe+e; 0.0027860];    % posicion del centro aerodinamico
    CM = [-0.203288; -0.00775; -0.0707140]; % posicion del centro de masa del motor
    COM = [0.0108830; 0.0004150; 0.0037860];% posicion del centro de masa del UAV
    
    Sm = CM - COM; % Vector de distancia del centro de masa del motor al centro de masa del cuerpo
    Sa = CA - COM; % Vector de distancia del centro de masa del centro aerodinamico al COM
    
    %Torque aerodinamico
    ta = cross(Sa, Fa) + [0;dM;0];
    
    %Torque del motor
    tm = cross(Sm,Fm);
    
    %Torque en el cuerpo
    tc = ta+tm;%[-up/5+20*w*up;v/390;-w/86];
    
    %Fuerzas en el cuerpo
    Fc = Fa + Fm + R'*[0;0;m*g]; %

% Vectores de los estados
nw = [phi theta psi].';     % Orientacion (diagrama inercial)
vc = [up v w].';  % Velocidad lineal (diagrama del cuerpo)
wc = [pp q r].';  % Velocidad angular (diagrama del cuerpo)
pw = [xp y z].';  % Posicion (diagrama inercial)


%Vector total del estado
X = [nw;vc; wc; pw]; %Se elimina las variables (yaw, x,y,z)

% Vector de entrada
U = [n; delta_f];

%% Dinamica translacional
pw_dot = R*vc;
vc_dot = 1/m*Fc-cross(m*wc, vc);

%% Dinamica rotacional
nw_dot = Winv*wc;
wc_dot = inv(I)*(tc-cross(wc, I*wc));

% Modelo no-lineal
dx = [nw_dot;
     vc_dot;
      wc_dot;
      pw_dot];

end      