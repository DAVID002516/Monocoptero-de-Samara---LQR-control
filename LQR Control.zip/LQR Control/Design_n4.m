%
%
%  A.A. Rodriguez
%  EEE598C:  Multivariable Control
%  Spring 1998
%
%  Copyright 1998
%
%
%********************************
%**                            **
%**  F404 Engine MATLAB Macro  **
%**                            **
%********************************
%


%***************************************************************************
%
% Topical Table of Contents
%
% Unscaled State Space
% Natural Modes - Eigenvalues and Eigenvectors
% Modal Analysis - Excitation of Individual Modes
% Transmission Zeros and Directions
% Zero-Pole-Gain form of all Transfer Functions
% Controllability Rank Test
% Observability Rank Test
% Frequency Response - Unscaled Singular Values
% SVD Analysis at DC
% SVD Analysis at another frequency
% Step Responses
% Variable Scaling
% Frequency Response - Scaled Singular Values
% LGG/LTRO (Linear Quadratic Gaussian with Loop Transfer Recovery at Plant Output) Design
%          Form Design Plant - Augment Plant with Integrators at Plant Input
%          Design Plant Singular Values
%          Design Target Loop Using Kalman Filter Theory
%                  Filter Open Loop: Matching at all Frequencies
%                  Adjust Target Loop Bandwidth
%                  Target Singular Values: Loop, Sensitivity, Complementary Sensitivity
%          Recover Target Loop Via Cheap Control Problem
%          Compensator Analysis: poles, zeros, singular values
%          Open Loop Analysis: poles, zeros, singular values
%          Closed Loop Analysis: poles, zeros, Sensitivity and Complemenatary Sensitivity singular values
%                                Postmultiplicative Error Robustness Test
%
%

clear % clear all variables
%
%***************************************************************************
%
% Unscaled State Space Dynamics
%
% u = [ W_f (pph)  A_8 (sq in) ]
% x = [ N_2 (rpm)  N_25 (rpm)  T_45 (deg Fah) ]
% y = [ N_2 (rpm)              T_45 (deg Fah) ]
%
%{
ap = [
-4.27E-07	-41.1497106194722	0	0	0	0.999999999996822	-0.00578178710015719	0.0651943396123675;
40.974188217682	-2.08E-11	0	0	0	0	0.996090494974425	0.0883386994762473;
0	-9.78606197065601	-0.000125237509290346	-17.2443009706083	-0.671180252397878	0	-0.226903642587477	-0.0156833277684728;
9.74780331218802	0.0565809268568221	17.2235079999992	0	1.13171959999943	-0.00132208379992545	0	0.00681065800001723;
0.864487987500138	-0.637995847556161	1.52941214737872	0.0932708707239652	-2.00902462456594	0.00986129600126482	0.411805017867007	0.342997331799723;
0	0	0.0073764322626523	4.65621410491397	-7.62611675898052	-0.00796395685801231	42.4063885312568	-2.16378306914364;
0	0	0.000549268801382258	0.365708737343423	-0.330892222896218	-40.8076461686223	-0.0828058996766958	3.0033835163196;
0	0	0.000263760510770282	0.0402164552505648	-1.84802157523217	0.50993873323846	0.680816477265123	0.0249568638497372];


bp = [
0	0;
0	0;
0	0.2729443304685;
-0.0360826759828102	0;
-0.0145795043676428	-3.81405957667851;
-0.0283146912158452	-14.5075034375684;
-0.0447555442045106	-1.58156133600686;
0.0465738602111871	-0.577001239354976];

cp = [0 0 1 0 0 0 0 0;
         0 0 0 0 1 0 0 0];

dp = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]')
%}
ap =[

   -0.0001  -17.2444;
   17.2235         0];


bp =[

         0   -9.7861;
    9.7478    0.0566];


cp =[

     1     0
     0     1];

dp = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]')
%***************************************************************************0	0

%
% FACTS ON SCALING: Scaling affects the shape of singular value plots.
%                   It does not alter pole locations, zero locations.
%                   It does alter directionality information.
%
%
% Scaling Matrices
%
%  unew = su uold
%  xnew = sx xold
%  ynew = sy yold
%
%
% New Control Variables
%     unew =  [ delta_e, elevator deflection from trim (deg)
%               delta_f, flaperon deflection (deg) ]
%
%
% New State Variables
%      xnew  = [ theta, perturbed pitch angle from trim (deg) 
%                gamma, perturbed flight path angle from trim (deg)
%                    q, pitch rate (deg/sec)
%                    u, perturbation from horizontal speed (ft/sec)  ]
%
%
% New Output Variables
%      ynew = [ theta, perturbed pitch angle from trim (deg)
%               gamma, perturbed flight path angle from trim (deg) ]
%
%r2d = 180/pi;
%su = diag( [r2d, r2d] )

%sx = diag([1, 1, 1, 1, 1, 1, 1, 1])


%***************************************************************************
%
% Natural Modes: Poles (Eigenvalues), Eigenvectors
%
[evec,eval] = eig(ap)   % evec contains eigenvectors
                        % eval contains poles or eigenvalues
                 
%***************************************************************************
%
% Unscaled Modal Analysis: We want to examine the natural modes (tendencies) of the F404 engine.
%
%
t = [0:0.1:25];
u = [0*t' 0*t'];         % Set input u to zero for all time in order to generate zero input response;
                         % i.e. response to an initial condition x_o.

%
% Excite F404 (slow) temperature mode.
% This mode 
%            is associated with a pole at s = - 0.4.
%            has a time constant of  2.5 sec and settles in about 12.5 sec.
%            is the slowest of the F404's three (3) modes.
%            is associated with T_45
% Comment: It takes a long time to change temperature!
%
y = lsim(ss(ap, bp, eye(2,2), 0*ones(2,2)), u, t, evec(:,1));% y = lsim(ss(ap, bp, eye(3,3), 0*ones(3,2)), u, t, evec(:,1));
figure(1)
plot(t,y)
grid
title('F404 Slow Temperature Mode: x_o = [ 0 0 1 ]')
ylabel('States')
xlabel('Time (seconds)')

%
% Excite slow rpm mode.
% This mode 
%            is associated with a pole at s =  -0.8963.
%            has a time constant of  1.12 sec and settles in about 5.58 sec.
%            is the slowest of the F404's two rpm modes.
%            is associated with N_2 and  N_25.
%
y = lsim(ss(ap, bp, eye(2,2), 0*ones(2,2)), u, t, evec(:,2)); 
figure(2)
plot(t,y)
grid
title('F404 Slow RPM Mode: x_o = [ -0.9638 -0.2245 0.1440 ]')
ylabel('States')
xlabel('Time (seconds)')

%
% Excite fast rpm mode.
% This mode 
%            is associated with a pole at s =  -2.7937.
%            has a time constant of  0.36 sec and settles in about 1.79 sec.
%            is the fastest of the F404's two rpm modes.
%            is associated with N_2 and  N_25.
%
y = lsim(ss(ap, bp, eye(2,2), 0*ones(2,2)), u, t, evec(:,2)); 
figure(3)
plot(t,y)
grid
title('F404 Fast RPM Mode: x_o = [ 0.8676  -0.4781  -0.1368 ]')
ylabel('States')
xlabel('Time (seconds)')


%return

%***************************************************************************
%
% Transmission Zeros
%
%z = tzero(ss(ap,bp,cp,dp))                % transmission zeros
[p,z] = pzmap(ss(ap,bp,cp,dp))                % transmission zeros
%zdir = null([z*eye(8)- ap  -bp; cp dp])   % transmission zero directions

%***************************************************************************
%
%
% F404 Engine TRANSFER FUNCTIONS: From u_i to x_j
%
sys = zpk(ss(ap,bp,eye(2,2),0*ones(2,2))) % Zeros, Poles, and Gains fron u_i to x_j



%***************************************************************************
%
% Controllability 
%
cm = [bp ap*bp (ap^2)*bp]  % Controllability Matrix
rcm= rank(cm)              % Rank of Controllability Matrix


%***************************************************************************
%
% Observability
%
om = [cp; 
      cp*ap;
      cp*(ap^2) ]          % Observability Matrix
rom = rank(om)             % Rank of Observability Matrix

%return

%***************************************************************************
%
%
% F404 FREQUENCY RESPONSE: Unscaled Singular Values
%
% u = [ W_f (pph)  A_8 (sq in) ]
% x = [ N_2 (rpm)  N_25 (rpm)  T_45 (deg Fah) ]
% y = [ N_2 (rpm)              T_45 (deg Fah) ]
%
w = logspace(-2,3,100);
sv = sigma(ss(ap, bp, cp, dp),w);
sv = 20*log10(sv);
figure(4)
semilogx(w, sv)
%clear sv
title('Outputs: N_2, T_45; Inputs: W_f/110, A_8/22')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%return

%***************************************************************************
%
% F404 SVD ANALYSIS at DC
%
dc =  cp*inv(-ap)*bp
[udc,sdc,vdc] = svd(dc)


%***************************************************************************
%
% F404 SVD Analysis at w = 0.1 rad/sec
%
s = j*0.1
g = cp*inv(s*eye(2)-ap)*bp + dp
[u, s, v ] = svd(g)

%***************************************************************************
%
% Step Response
%
t = [0:0.1:25];
y = step(ss(ap, bp, eye(2,2), 0*ones(2,2)), t); % Step response for each state and each input

%
% Step Response due to W_f
%

%
% N_2: Due to W_f
%
figure(5)
plot(t,y(:,1,1))
grid
title('N_2 response for W_f =  Unit Step')
ylabel('N_2 (rpm)')
xlabel('Time (seconds)')

%return

%
% N_25: Due to W_f
%
figure(6)
plot(t,y(:,2,1))
grid
title('N_{25} response for W_f =  Unit Step')
ylabel('N_{25} (rpm)')
xlabel('Time (seconds)')

%return

%
% T_45: Due to W_f
%
figure(7)
plot(t,y(:,2,1))
grid
title('T_{45} response for W_f =  Unit Step')
ylabel('T_{45} (deg F)')
xlabel('Time (seconds)')

%return

%
% Step Response due to A_8
%

%
% N_2: Due to A_8
%
figure(8)
plot(t,y(:,1,2))
grid
title('N_2 response for A_8 =  Unit Step')
ylabel('N_2 (rpm)')
xlabel('Time (seconds)')

%return

%
% N_25: Due to W_f
%

figure(9)
plot(t,y(:,2,2))
grid
title('N_{25} response for A_8 =  Unit Step')
ylabel('N_{25} (rpm)')
xlabel('Time (seconds)')

%return

%
% T_45: Due to W_f
%
figure(10)
plot(t,y(:,2,2))
grid
title('T_{45} response for A_8 =  Unit Step')
ylabel('T_{45} (deg F)')
xlabel('Time (seconds)')

%return

%return

%
% FACTS ON SCALING: Scaling affects the shape of singular value plots.
%                   It does not alter pole locations, zero locations.
%                   It does alter directionality information.
%

%
% Scaling Matrices
%
%  unew = su uold
%  xnew = sx xold
%  ynew = sy yold
%

sy = diag( [1/(pi/180), 1/(pi/180)] )% roll pitch % 12 kRPM
sx = diag([1/10, 1/10])% u v
su = diag( [1/10,        1/10] )% u v

%
% Scaled F404 Dynamics
%
%
% u = [ W_f/110    A_8/22 ]
% x = [ N_2/250  N_25/350  T_45/28 ]
% y = [ N_2/250            T_45/28 ]inv(sy)
%
ap = sx*ap*inv(sx)
bp = sx*bp*inv(su)
cp = sy*cp*inv(sx)
dp = sy*dp*inv(su)
    
%
% F404 FREQUENCY RESPONSE: Scaled Singular Values
%
sv = sigma(ss(ap, bp, cp, dp),w);
sv = 20*log10(sv);
figure(11)
semilogx(w, sv)
%clear sv
title('Outputs: N_2/250, T_45/350; Inputs: W_f/110, A_8/22')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Augment Plant with Integrators at Plant Input and Plot Singular Values
%
[ns nc] = size(bp);                      % ns = number of inputs;  nc = number of controls;   
a = [ ap             bp
      0*ones(nc,ns)    0*ones(nc,nc) ]

b = [ 0*ones(ns,nc)
      eye(nc)      ]

c = [ cp  0*ones(nc,nc) ]

d = 0*ones(nc,nc)
sv = sigma(ss(a, b, c, d),w);
sv = 20*log10(sv);
figure(12)
semilogx(w, sv)
%clear sv
title('Design Plant Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%return


%
%*********************************************************************************************
%


%
% Design of Target Loop Singular Values Using Kalman Filter
%
ll =  inv(cp*inv(-ap)*bp + dp);     % Choose ll and lh to match singular values at all frequencies
lh = -inv(ap)*bp*ll;
l = [lh 
     ll];                           % ll, lh - for low and high frequency loop shaping

sv = sigma(ss(a, l, c, d),w);
sv = 20*log10(sv);
figure(13)
semilogx(w, sv)
%clear sv
title('Filter Open Loop (G_{FOL}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


pnint = eye(nc)                                    % Process Noise Intensity Matrix
mu = 0.01;%0.01;                                         % Measurement Noise Intesity; Used to adjust Kalman Filter Bandwidth
                                                   % Small mu - expensive sensor   - large bandwidth
                                                   % Large mu - inexpensive sensor - small bandwidth
mnint = mu*eye(nc)                                 % Measurement Noise Intensity Matrix 
% sysKal=ss(a, [b l], c, [d 0*ones(nc,nc)]);
% [kest, h, sig]= kalman(sysKal,pnint, mnint);  % Compute Filter Gain Matrix h
%[sig, poles, g1, rr] = care(a',c',l*l', mnint);                          
[sig, poles, g1] = care(a',c',l*l', mnint);                          
% Alternate Method for Computing h
h = g1';
sv = sigma(ss(a, h, c, d),w);
tsv = 20*log10(sv);
figure(15)
semilogx(w, tsv)
%clear sv
title('Target Loop (G_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

tolpoles = eig(a)                           % Target Open Loop Poles
%targzeros = tzero(a,h,c,0*ones(nc,nc))      % Target Open Loop Zeros
[targpoles,targzeros] = pzmap(ss(a,h,c,0*ones(nc,nc)))      % Target Open Loop Zeros
tclpoles = eig(a-h*c)                       % Target Closed Loop Poles

sv = sigma(ss(a-h*c, h, -c, eye(nc)),w);
sv = 20*log10(sv);
figure(16)
semilogx(w, sv)
%clear sv
title('Target Sensitivity (S_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


sv = sigma(ss(a-h*c, h, c, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(17)
semilogx(w, sv, w, 20*log10(10./w))
%clear sv
title('Target Complementary (T_{KF}) Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Recover Target Loop By Solving Cheap LQR Problem
%
q = c'*c;                                            % State Weighting Matrix
rho = 1e-15;%1e-3                                     % Cheap control recovery parameter;
                                                     % The smaller the parameter, the better the recovery.
r = rho*eye(nc)                                      % Control Weigthing Matrix
%[k, poles, g, rr] = care(a,b,q,r);                   % Compute Control Gain Matrix G
[k, poles, g] = care(a,b,q,r);                   % Compute Control Gain Matrix G


%
% Compensator Analysis
%
ak = [ a-b*g-h*c  0*ones(ns+nc,nc)
       g          0*ones(nc,nc) ]

bk = [ h
       0*ones(nc,nc) ]

ck = [0*ones(nc, ns+nc) eye(nc,nc) ]

dk = 0*eye(2);

%cpoles = eig(ak)                               % Compensator Poles
%czeros = tzero(a, h, g, 0*ones(nc,nc))         % Compensator Zeros
[cpoles, czeros] = pzmap(ss(a, h, g, 0*ones(nc,nc)))         % Compensator Zeros
%zerocheck = tzero(ak, bk, ck, 0*ones(nc,nc))   % Check Compensator Zeros
[polecheck, zerocheck] = pzmap(ss(ak, bk, ck, 0*ones(nc,nc)))   % Check Compensator Zeros

sv = sigma(ss(ak, bk, ck, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(18)
semilogx(w, sv)
%clear sv
title('Compensator Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')


%
% Open Loop Analysis
%
al = [ ap                     bp*ck
       0*ones(ns+nc+nc,ns)    ak    ]

bl = [ 0*ones(ns,nc)
       bk ]
    
cl = [ cp  0*ones(nc,ns+nc+nc) ]
    
%olpoles = eig(al)                          % Open Loop Poles
%olzeros = tzero(al,bl,cl,0*ones(nc,nc))    % Open Loop Zeros
[olpoles, olzeros] = pzmap(ss(al,bl,cl,0*ones(nc,nc)))    % Open Loop Zeros    
sv = sigma(ss(al, bl, cl, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(19)
semilogx(w, sv, w, tsv)
%clear sv
title('Open Loop Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%
% Closed Loop Analysis
%
clpoles = eig(al-bl*cl)           % Closed Loop Poles
clpkf = eig(a - h*c)              % Closed Loop Poles Due to Kalman Filter
clpreg = eig(a - b*g)             % Closed Loop Poles Due to Regulator


sv = sigma(ss(al-bl*cl, bl, -cl, eye(nc)),w);
sv = 20*log10(sv);
figure(20)
semilogx(w, sv)
%clear sv
title('Sensitivity Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

sv = sigma(ss(al-bl*cl, bl, cl, 0*eye(nc)),w);
sv = 20*log10(sv);
figure(21)
semilogx(w, sv)
%clear sv
title('Complementary Sensitivity Singular Values')
grid
xlabel('Frequency (rad/sec)')
ylabel('Singular Values (dB)')

%
% Step Response in Closed Loop 
%

[y,t] = step(ss(al-bl*cl, bl, cl, 0*eye(nc)));
figure(22)
plot(t,y(:,1,1))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 1 response caused by input 1')
%return

%
figure(23)
plot(t,y(:,1,2))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 1 response caused by input 2')

figure(24)
plot(t,y(:,2,1))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 2 response caused by input 1')
%return

%
figure(25)
plot(t,y(:,2,2))
xlabel('Time (s)')
ylabel('Amplitude')
title('output 2 response caused by input 2')
%{
apo = [
-4.27E-07	-41.1497106194722	0	0	0	0.999999999996822	-0.00578178710015719	0.0651943396123675;
40.974188217682	-2.08E-11	0	0	0	0	0.996090494974425	0.0883386994762473;
0	-9.78606197065601	-0.000125237509290346	-17.2443009706083	-0.671180252397878	0	-0.226903642587477	-0.0156833277684728;
9.74780331218802	0.0565809268568221	17.2235079999992	0	1.13171959999943	-0.00132208379992545	0	0.00681065800001723;
0.864487987500138	-0.637995847556161	1.52941214737872	0.0932708707239652	-2.00902462456594	0.00986129600126482	0.411805017867007	0.342997331799723;
0	0	0.0073764322626523	4.65621410491397	-7.62611675898052	-0.00796395685801231	42.4063885312568	-2.16378306914364;
0	0	0.000549268801382258	0.365708737343423	-0.330892222896218	-40.8076461686223	-0.0828058996766958	3.0033835163196;
0	0	0.000263760510770282	0.0402164552505648	-1.84802157523217	0.50993873323846	0.680816477265123	0.0249568638497372];


bpo = [
0	0;
0	0;
0	0.2729443304685;
-0.0360826759828102	0;
-0.0145795043676428	-3.81405957667851;
-0.0283146912158452	-14.5075034375684;
-0.0447555442045106	-1.58156133600686;
0.0465738602111871	-0.577001239354976];

     
 cpo =[0     0     1     0     0     0     0    0;% vx
      0     0     0     0     1     0     0    0];% vz

dpo = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]')
%}
apo =[

   -0.0001  -17.2444;
   17.2235         0];


bpo =[

         0   -9.7861;
    9.7478    0.0566];


cpo =[

     1     0
     0     1];

dpo = 0*ones(size(cp)*[1 0]', size(bp)*[0 1]')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HOVER CONTROLLER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    syms xp y z up v w phi theta psi pp q r
    
    syms Fc Fa Fm T Fg n delta_f
    
    syms CL0 CLa CLd CLq CD0 CDa CDd CM0 CMa CMd CMq Iz Iy Ix theta_p rho D Ctm g m
    
    syms F1 F3 M dF1 dF3 dM %dSp
    
    % Transformation matrix from body angular velocity to Tait-Bryan rates
    W = [ 1, 0,      -sin(theta)         ;
      0, cos(phi),  cos(theta)*sin(phi)  ;
      0, -sin(phi), cos(theta)*cos(phi) ];

    Winv = simplify(inv(W));
  %
    % Rotation matrix from body to world frame, input: roll, pitch, yaw
    R = [cos(theta)*cos(psi), sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi), cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi) ;
     cos(theta)*sin(psi), sin(phi)*sin(theta)*sin(psi)+cos(phi)*cos(psi), cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi) ;
     -sin(theta),       sin(phi)*cos(theta),                      cos(phi)*cos(theta)                     ];

    % Matrix of mass inertia
    I = [Ix             -0.001           7.868*10^(-5)  ;
         -0.001          Iy             -7.185*10^(-5)  ;
         7.868*10^(-5)  -7.185*10^(-5)      Iz];
 
 %Definciones
 
    %Ra = 2*10^(-2);                  % Radio del disco
    Adisk = 0.019;      % Area del disco (m^2)
    Rl = 0.4000; % Wingspan (m)
    e = 0.08; %excentricidad (m)
    vi = sqrt(m*g/(2*rho*pi*Rl^2));    % Velocidad inducida
    lbe = (Rl/2+e);          % radio vector del blade element % Es de otro paper el valor
    vce = [up;v;w] + cross([pp;q;r],[lbe;0;0])+[0;0;vi]; % Vector de la velocidad del blade element
    T = rho*n^2*D^4*Ctm;    % Empuje 
    qb = 0.5*rho*(norm(vce))^2;% Presion dinamica
    a_inc = 0.1919; % angulo de incidencia 11 grados
    a_atk = atan(vce(3,1)/(vce(2,1))); % angulo de ataque Up/Ut
    a_eff = a_inc - a_atk; % angulo de efectivo de ataque
    c = 0.175; % Distancia media del chord en metros 150, 200
    S = 0.0190; % m^2 Area del pala % Es de  otro paper el valor
    CL = CL0 + CLa*a_eff + CLd*delta_f + CLq*q*c/(2*norm(vce)); %Coeficiente aerodinamico de sustentacion
    CD = CD0 + CDa*abs(a_eff) + CDd*abs(delta_f); % Coeficiente aerodinamico de arrastre
    dL =  qb*CL*S;
    dD =  qb*CD*S;
    
   

% Coeficiente aerodinamico del momento en el monocoptero
CM1 = CM0 + CMa*a_eff + CMd*delta_f + CMq*0.5*q*c/(norm(vce));
    
    % Fuerza aerodinamica
    dF1 = dD*cos(a_atk) + dL*sin(a_atk); % dA debe tenderer F1 = 0
    dF3 = dL*cos(a_atk) - dD*sin(a_atk);% dN
    dM = qb*c*CM1*S; % dM
    %dSp = 0.5*rho*norm(vce)*vce(2,1)*CD*S;% Fuerza de respuesta del aleron (valor minimo no considerado)
    
    
    Fa = [-dF1; 0; -dF3];
    Fm = [0;T*cos(theta_p);T*sin(theta_p)];
    
    %Corregir los torques
    
    CA = [0.0118830; lbe+e; 0.0027860];    % posicion del centro aerodinamico
    CM = [-0.203288; -0.00775; -0.0707140]; % posicion del centro de masa del motor
    COM = [0.0108830; 0.0004150; 0.0037860];% posicion del centro de masa del UAV
    
    Sm = CM - COM; % Vector de distancia del centro de masa del motor al centro de masa del cuerpo
    Sa = CA - COM; % Vector de distancia del centro de masa del centro aerodinamico al COM
    
    %Torque aerodinamico
    ta = cross(Sa, Fa) + [0;dM;0];
    
    %Torque del motor
    tm = cross(Sm,Fm);
    
    %Torque en el cuerpo
    tc = ta+tm;
    
    %Fuerzas en el cuerpo
    Fc = Fa + Fm + R'*[0;0;m*g]; %

% Vectores de los estados
nw = [phi theta psi].';     % Orientacion (diagrama inercial)
vc = [up v w].';  % Velocidad lineal (diagrama del cuerpo)
wc = [pp q r].';  % Velocidad angular (diagrama del cuerpo)
pw = [xp y z].';  % Posicion (diagrama inercial)


%Vector total del estado
%full system 12x12
X_full = [nw;vc;wc;pw];
%8x8 system
X = [nw(1);nw(2); vc; wc]; %Se elimina las variables (yaw, x,y,z)
%-Subsistema de altitud y orientacion
X_red = [nw(1);nw(2); vc(3); wc]; % Reduced state vector (only attitude and altitude)
X_hor = [vc(1); vc(2)]; % Reduced state vector for horizontal movements

X_roll = [nw(1); wc(1); vc(1)];

% Input vector for horizontal model
U_hor = [phi; theta];

% Roll 
U_roll = [delta_f];
% Vector de entrada
U = [n; delta_f];

%% Dinamica translacional
pw_dot = R*vc;
vc_dot = 1/m*Fc-cross(m*wc, vc);

%% Dinamica rotacional
nw_dot = Winv*wc;
wc_dot = inv(I)*(tc-cross(wc, I*wc));

% Modelo no-lineal completo
f_full = [nw_dot;
          vc_dot;
          wc_dot;
          pw_dot];
% Modelo no-lineal combinado
f = [nw_dot(1);
     nw_dot(2);
      vc_dot;
      wc_dot];
% Reduced non-linear model
f_red = [ nw_dot(1);
          nw_dot(2);
          vc_dot(3);
          wc_dot     ];
      
% Horizontal non-linear model
f_hor = [ vc_dot(1) ;
          vc_dot(2)];
      
      
f_roll = [ nw_dot(1) ;
          wc_dot(1)  ;
          vc_dot(1) ]; 
  
%Usando el metodo del Jacobiano, se calcula la matriz de variables adjuntas al
%sistema

%Full system 12x12

A_full = jacobian(f_full, X_full);
B_full = jacobian(f_full, U);
C_full = jacobian(X_full, X_full);
D_full = jacobian(X_full, U);

%A 8x8

A = jacobian(f, X);
B = jacobian(f, U);
C = jacobian(X, X);
Dsys = jacobian(X, U);

% Reduced model (only z-axis in position)
A2 = jacobian(f_red, X_red);
B2 = jacobian(f_red, U);
C2 = jacobian(X_red, X_red);

% Horizontal model (only x- and y-direction)
A3 = jacobian( f_hor, X_hor );
B3 = jacobian( f_hor, U_hor );


% Single dimension model (roll/x axis)
A4 = jacobian( f_roll, X_roll );
B4 = jacobian( f_roll, U_roll );

% Todos los estados son cero en el punto de suspension
xp = 2.6319*10^(-10); y = 1.4418*10^(-11); z = -50; up = -0.016139; v = -0.023368; w = 0; 
phi = -0.088454; theta = 0.065357; psi = 0; pp = 2.6818; q = 3.6196; r = -40.814;

% Se tiene entradas diferente a cero
delta_f = 0.071578; % angulo del flap
n = -90;% velocidad del motor rps

% initu = [-0.515;0.071578]; [-0.088454;0.065357;0;-0.016139;-0.023368;-0.065357;2.6818;3.6196;-40.814;2.6319*10^(-10);1.4418*10^(-11);-50];



% Constantes monocoptero
CL0 = 0.4;        % -
CLa = 6.8755;    % 1/rad
CLd = 1.17;        % 1/rad
CLq = 5.8;        % 1/rad
CD0 = 0.02;        % -
CDa = 0.063;       % 1/rad
CDd = 0.01;        % 1/rad
CM0 = -0.0950;
% -
CMa = -0.1;        % 1/rad
CMd = -0.1425;     % 1/rad
CMq = -2.5;        % 1/rad
m = 0.4220;        % kg
theta_p = 0.384;   % rad
rho = 1.1;         % kg/m^3
D = 0.12;          % m
Ctm = 0.4;         % -
Ix = 0.04;         % kg*m^2
Iy = 0.03;        % kg*m^2
Iz = 0.07;        % kg*m^2
g = 9.807;         % m/s^2

% Se evaluan las matrices A y B, obteniendo el modelo lineal completo alrededor del punto de sustentancin
%Full system 12x12

%Full system 12x12
A_fsys = double(vpa(subs(A_full), 4))
B_fsys = double(vpa(subs(B_full), 4))
C_fsys = double(vpa(subs(C_full), 4))
D_fsys = double(vpa(subs(D_full), 4))

%8x8
A_sys = double(vpa(subs(A), 4))
B_sys = double(vpa(subs(B), 4))
C_sys = double(vpa(subs(C), 4))
D_sys = double(vpa(subs(Dsys), 4))

% Reduced model 
A_red = double(vpa(subs(A2), 4))
B_red = double(vpa(subs(B2), 4))
C_red = double(vpa(subs(C2), 4))
D_red = zeros(6,2);

% Horizontal model
A_hor = double(vpa(subs(A3),4))
B_hor = double(vpa(subs(B3),4))
C_hor = eye(2)
D_hor = zeros(2,2);

%% Open Loop dynamics

sys = ss(A_sys,B_sys,C_sys,D_sys);
sys_red = ss(A_red,B_red,C_red,D_red);
%sys_int = ss(A_int,B_int,C_int, D_int);
sys_hor = ss(A_hor, B_hor, C_hor, D_hor);
%sys_hint = ss(A_hint, B_hint, C_hint, D_hint);

%% Diseo del controlador

% Regla de Bryson
% Max angle of 0.3 radians. Maximum angular rate of 5 rad/second000
% Maximo angulo de 0.3 rad. Maxima tasa angular de 5 rad/s
Q = [ 1/0.5^2     0     0      0      0      0  ;  % Roll
      0        1/0.5^2  0      0      0      0  ;  % Pitch
      0        0        1/4^2  0      0      0  ;  % w
      0        0        0      1/4^2  0      0  ;  % p
      0        0        0      0      1/4^2  0  ;  % q
      0        0        0      0      0      1/4^2 ]; %r 
     
Q_red = Q;  

% Accion integral
%Q(9,9) = [ 1/15^2 ]; % z

% Max actuation angle of +-10 degress
%R = [ 1/0.01^2   0       ; % delta_f
%      0        1/1^2  ]; % n

R = [ 1/90^2   0       ; % n
      0        1/0.13^2  ]; % delta_f
      

% Maxima actuacion deQ, R);
K_red = lqr(sys_red, Q_red, R);
K_hov = lqr(sys_red, Q, R);

% Calculo del limite integral que coincide con la velocidad
%del motor en el regimen estacionario
int_lim = n/K_hov(2,6) + n*0.005;

sys_d = c2d(sys_red, 0.008*10^(-3), 'zoh' )

%K_lqrd = dlqr(A_red, B_red, Q, R);
 
matrix_to_cpp( K_hov )
Ctrb = ctrb(sys_d.A, sys_d.B)
rank_Ctrb = rank(Ctrb)
%ctrb_matrix = ctrb(sys_d, B_sys);

% Calcuate closed loop system
%figure(1)
%cl_sys = ss((A_red - B_red*K_red), B_red, C_red, D_red );
sys_cl_hov = feedback( sys_red*K_red, C_red);
%figure(3)
%step(sys_cl_hov)

figure(1)
pzmap(sys_cl_hov);%pzmap(sys_cl_hov);
[phi,z] = pzmap(sys_cl_hov)%[phi,z] = pzmap(sys_cl_hov)
grid on

Q_pos = [ 1/0.1^2  0        ;% u
          0        1/0.1^2 ];% v

Q_hor = Q_pos;      
           
%R_pos = [ 1/0.00000005^2  0;
%          0          1/0.00000005^2];

R_pos = [ 1/0.01^2  0;
          0          1/0.01^2];
%K_pos = lqr(sys_hint, Q_pos, R_pos);
K_hor = lqr(sys_hor, Q_hor, R_pos);
matrix_to_cpp( K_hor )
sys_cl_pos = feedback( sys_hor*K_hor, C_hor);
figure(2)
pzmap(sys_cl_pos);
[phi2,z2] = pzmap(sys_cl_pos)
grid on

%sys_total = series( sys_cl_pos, sys_cl_pos )matrix_to_cpp( K_pos )

% Symbolic Discretization

% syms dt;
% M = expm([A_sym, B_sym; zeros(12,12), zeros(12,2) ]*dt);
% 
% Ad = M(1:12, 1:12);
% Bd = M(1:12, 13:17);

%Roll and pitch Control


%% Functions 

function matrix_to_cpp( matrix)

    name = inputname(1);
    [m, n] = size(matrix);
    
    tol = 1.e-6;
    matrix(matrix<0 & matrix>-tol) = 0;
    
    fprintf('Matrix %s \n', name);
    
    for i = 1:m
        line = string();
        for j = 1:n
            str = sprintf('%.4f,', round( matrix(i,j), 4 ) );
            value = pad(str, 10, 'left');

            line = append( line, value );
        end
        disp(line);
    end
end
